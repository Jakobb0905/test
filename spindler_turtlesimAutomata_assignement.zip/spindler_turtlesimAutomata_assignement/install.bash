#!/bin/bash

# Make sure the script is run from the parent folder
if [[ ! -f "install.bash" ]]; then
    echo "Please run the script from the parent folder"
    exit 1
fi

# Get current folder
current_folder=$(pwd)

echo "Creating ros2_ws folder"
mkdir -p ~/ros2_ws/src/

#moving files to the ros2 workspace
echo "moving files"
cp -rf ./turtlesimAutomata ~/ros2_ws/src
cp -rf ./turtlesim ~/ros2_ws/src

#changing to the workspace
cd ~/ros2_ws

#removing the downloaded folder
rm -rf "$current_folder"

#sourcing
source install/setup.bash
source opt/ros/humble/setup.bash

#building
echo "Starting build process..."
colcon build --packages-select turtlesimAutomata turtlesim

#sourcing
source install/setup.bash
source opt/ros/humble/setup.bash

#starting the package
echo "starting the turtlesimAutomata"
ros2 launch turtlesimAutomata turtlesimAutomata_launch.xml
